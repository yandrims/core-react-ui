import React from 'react';

/** elements */
import Spinner from '../../elements/Spinner';

class InfiniteScrollDesktop extends React.PureComponent {
  componentDidMount() {
    this.props.onScrollHandler();
  }

  render() {
    return this.props.status === 'loading' ? (
      <Spinner size={this.props.spinnerSize} />
    ) : (
      ''
    );
  }
}

export default InfiniteScrollDesktop;
