import React from 'react';
import PropTypes from 'prop-types';

/** elements */
import InfiniteScrollMobile from './InfiniteScrollMobile';
import InfiniteScrollDesktop from './InfiniteScrollDesktop';
import { isElementInViewport } from '../../utils';

import { InfiniteContainer } from './StyledInfiniteScroll';

class InfiniteScroll extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      isInViewport: false
    };
    this.onScrollHandler = this.onScrollHandler.bind(this);
  }

  onScrollHandler() {
    const { triggerFunction, status } = this.props;
    document.addEventListener('scroll', () => {
      if (this.element !== null && isElementInViewport(this.element)) {
        if (!this.state.isInViewport) {
          if (status !== 'loading') {
            if (triggerFunction && typeof triggerFunction === 'function') {
              this.props.triggerFunction();
              setTimeout(() => {
                this.setState({ isInViewport: false });
              }, 1000);
            }
          } else {
            this.setState({ isInViewport: true });
          }
        }
      }
    });
  }

  render() {
    const {
      status,
      triggerFunction,
      spinnerSize,
      timeout,
      isMobile,
      isAmp
    } = this.props;

    const props = {
      status,
      triggerFunction,
      spinnerSize,
      timeout,
      isMobile,
      isAmp,
      onScrollHandler: this.onScrollHandler
    };

    if (isMobile) {
      return (
        <InfiniteContainer ref={el => (this.element = el)}>
          <InfiniteScrollMobile {...props} />
        </InfiniteContainer>
      );
    }

    return (
      <InfiniteContainer ref={el => (this.element = el)}>
        <InfiniteScrollDesktop {...props} />
      </InfiniteContainer>
    );
  }
}

InfiniteScroll.propTypes = {
  status: PropTypes.oneOf(['init', 'loading', 'success', 'error']),
  triggerFunction: PropTypes.func,
  spinnerSize: PropTypes.number.isRequired,
  timeout: PropTypes.number,
  isMobile: PropTypes.bool.isRequired,
  isAmp: PropTypes.bool.isRequired
};

InfiniteScroll.defaultProps = {
  timeout: 1000,
  spinnerSize: 48,
  isMobile: false,
  isAmp: false
};

export default InfiniteScroll;
