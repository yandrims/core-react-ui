### Usage

```markdown
import { InfiniteScroll } from 'sehatq-quick-ui';
```

#### Examples

```jsx
let i = 1;
const renderFunc = () => {
  console.log('render new items', i++);
};
<div>
  <p>
    dak seperti anggapan banyak orang, Lorem Ipsum bukanlah teks-teks yang
    diacak. Ia berakar dari sebuah naskah sastra latin klasik dari era 45
    sebelum masehi, hingga bisa dipastikan usianya telah mencapai lebih dari
    2000 tahun. Richard McClintock, seorang professor Bahasa Latin dari
    Hampden-Sidney College di Virginia, mencoba mencari makna salah satu kata
    latin yang dianggap paling tidak jelas, yakni consectetur, yang diambil dari
    salah satu bagian Lorem Ipsum. Setelah ia mencari maknanya di di literatur
    klasik, ia mendapatkan sebuah sumber yang tidak bisa diragukan. Lorem Ipsum
    berasal dari bagian 1.10.32 dan 1.10.33 dari naskah "de Finibus Bonorum et
    Malorum" (Sisi Ekstrim dari Kebaikan dan Kejahatan) karya Cicero, yang
    ditulis pada tahun 45 sebelum masehi. BUku ini adalah risalah dari teori
    etika yang sangat terkenal pada masa Renaissance. Baris pertama dari Lorem
    Ipsum, "Lorem ipsum dolor sit amet..", berasal dari sebuah baris di bagian
    1.10.32. Bagian standar dari teks Lorem Ipsum yang digunakan sejak tahun
    1500an kini di reproduksi kembali di bawah ini untuk mereka yang tertarik.
    Bagian 1.10.32 dan 1.10.33 dari "de Finibus Bonorum et Malorum" karya Cicero
    juga di reproduksi persis seperti bentuk aslinya, diikuti oleh versi bahasa
    Inggris yang berasal dari terjemahan tahun 1914 oleh H. Rackham.{' '}
  </p>
  <p>
    udah merupakan fakta bahwa seorang pembaca akan terpengaruh oleh isi tulisan
    dari sebuah halaman saat ia melihat tata letaknya. Maksud penggunaan Lorem
    Ipsum adalah karena ia kurang lebih memiliki penyebaran huruf yang normal,
    ketimbang menggunakan kalimat seperti "Bagian isi disini, bagian isi
    disini", sehingga ia seolah menjadi naskah Inggris yang bisa dibaca. Banyak
    paket Desktop Publishing dan editor situs web yang kini menggunakan Lorem
    Ipsum sebagai contoh teks. Karenanya pencarian terhadap kalimat "Lorem
    Ipsum" akan berujung pada banyak situs web yang masih dalam tahap
    pengembangan. Berbagai versi juga telah berubah dari tahun ke tahun, kadang
    karena tidak sengaja, kadang karena disengaja (misalnya karena dimasukkan
    unsur humor atau semacamnya),
  </p>
  <p>
    dak seperti anggapan banyak orang, Lorem Ipsum bukanlah teks-teks yang
    diacak. Ia berakar dari sebuah naskah sastra latin klasik dari era 45
    sebelum masehi, hingga bisa dipastikan usianya telah mencapai lebih dari
    2000 tahun. Richard McClintock, seorang professor Bahasa Latin dari
    Hampden-Sidney College di Virginia, mencoba mencari makna salah satu kata
    latin yang dianggap paling tidak jelas, yakni consectetur, yang diambil dari
    salah satu bagian Lorem Ipsum. Setelah ia mencari maknanya di di literatur
    klasik, ia mendapatkan sebuah sumber yang tidak bisa diragukan. Lorem Ipsum
    berasal dari bagian 1.10.32 dan 1.10.33 dari naskah "de Finibus Bonorum et
    Malorum" (Sisi Ekstrim dari Kebaikan dan Kejahatan) karya Cicero, yang
    ditulis pada tahun 45 sebelum masehi. BUku ini adalah risalah dari teori
    etika yang sangat terkenal pada masa Renaissance. Baris pertama dari Lorem
    Ipsum, "Lorem ipsum dolor sit amet..", berasal dari sebuah baris di bagian
    1.10.32. Bagian standar dari teks Lorem Ipsum yang digunakan sejak tahun
    1500an kini di reproduksi kembali di bawah ini untuk mereka yang tertarik.
    Bagian 1.10.32 dan 1.10.33 dari "de Finibus Bonorum et Malorum" karya Cicero
    juga di reproduksi persis seperti bentuk aslinya, diikuti oleh versi bahasa
    Inggris yang berasal dari terjemahan tahun 1914 oleh H. Rackham.{' '}
  </p>
  <p>
    udah merupakan fakta bahwa seorang pembaca akan terpengaruh oleh isi tulisan
    dari sebuah halaman saat ia melihat tata letaknya. Maksud penggunaan Lorem
    Ipsum adalah karena ia kurang lebih memiliki penyebaran huruf yang normal,
    ketimbang menggunakan kalimat seperti "Bagian isi disini, bagian isi
    disini", sehingga ia seolah menjadi naskah Inggris yang bisa dibaca. Banyak
    paket Desktop Publishing dan editor situs web yang kini menggunakan Lorem
    Ipsum sebagai contoh teks. Karenanya pencarian terhadap kalimat "Lorem
    Ipsum" akan berujung pada banyak situs web yang masih dalam tahap
    pengembangan. Berbagai versi juga telah berubah dari tahun ke tahun, kadang
    karena tidak sengaja, kadang karena disengaja (misalnya karena dimasukkan
    unsur humor atau semacamnya),
  </p>
  <p>
    dak seperti anggapan banyak orang, Lorem Ipsum bukanlah teks-teks yang
    diacak. Ia berakar dari sebuah naskah sastra latin klasik dari era 45
    sebelum masehi, hingga bisa dipastikan usianya telah mencapai lebih dari
    2000 tahun. Richard McClintock, seorang professor Bahasa Latin dari
    Hampden-Sidney College di Virginia, mencoba mencari makna salah satu kata
    latin yang dianggap paling tidak jelas, yakni consectetur, yang diambil dari
    salah satu bagian Lorem Ipsum. Setelah ia mencari maknanya di di literatur
    klasik, ia mendapatkan sebuah sumber yang tidak bisa diragukan. Lorem Ipsum
    berasal dari bagian 1.10.32 dan 1.10.33 dari naskah "de Finibus Bonorum et
    Malorum" (Sisi Ekstrim dari Kebaikan dan Kejahatan) karya Cicero, yang
    ditulis pada tahun 45 sebelum masehi. BUku ini adalah risalah dari teori
    etika yang sangat terkenal pada masa Renaissance. Baris pertama dari Lorem
    Ipsum, "Lorem ipsum dolor sit amet..", berasal dari sebuah baris di bagian
    1.10.32. Bagian standar dari teks Lorem Ipsum yang digunakan sejak tahun
    1500an kini di reproduksi kembali di bawah ini untuk mereka yang tertarik.
    Bagian 1.10.32 dan 1.10.33 dari "de Finibus Bonorum et Malorum" karya Cicero
    juga di reproduksi persis seperti bentuk aslinya, diikuti oleh versi bahasa
    Inggris yang berasal dari terjemahan tahun 1914 oleh H. Rackham.{' '}
  </p>
  <p>
    udah merupakan fakta bahwa seorang pembaca akan terpengaruh oleh isi tulisan
    dari sebuah halaman saat ia melihat tata letaknya. Maksud penggunaan Lorem
    Ipsum adalah karena ia kurang lebih memiliki penyebaran huruf yang normal,
    ketimbang menggunakan kalimat seperti "Bagian isi disini, bagian isi
    disini", sehingga ia seolah menjadi naskah Inggris yang bisa dibaca. Banyak
    paket Desktop Publishing dan editor situs web yang kini menggunakan Lorem
    Ipsum sebagai contoh teks. Karenanya pencarian terhadap kalimat "Lorem
    Ipsum" akan berujung pada banyak situs web yang masih dalam tahap
    pengembangan. Berbagai versi juga telah berubah dari tahun ke tahun, kadang
    karena tidak sengaja, kadang karena disengaja (misalnya karena dimasukkan
    unsur humor atau semacamnya), Sehatq sangat sehat
  </p>
  <InfiniteScroll triggerFunction={renderFunc} status="init" spinnerSize={48} />
</div>;
```
