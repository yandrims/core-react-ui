import InfiniteScroll from './InfiniteScroll';

export default InfiniteScroll;
