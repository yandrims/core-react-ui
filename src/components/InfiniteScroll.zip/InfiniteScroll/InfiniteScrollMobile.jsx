import React from 'react';

/** elements */
import Spinner from '../../elements/Spinner';
import Box from '../../elements/Box';

class InfiniteScrollMobile extends React.PureComponent {
  componentDidMount() {
    this.props.onScrollHandler();
  }

  render() {
    return this.props.status === 'loading' ? (
      <Spinner size={this.props.spinnerSize} />
    ) : (
      ''
    );
  }
}

export default InfiniteScrollMobile;
