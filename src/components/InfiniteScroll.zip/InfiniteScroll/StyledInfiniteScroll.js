import styled from 'styled-components';

const InfiniteContainer = styled.div`
  flex: 1;
  margin-top: -2px;
`;

export { InfiniteContainer };
